// const dotenv = require('dotenv')
// dotenv.config({path: __dirname+"./.env"})
// console.log(process.env)
// require('dotenv').config({path: __dirname+"./.env"})
// const {SMPT_MAIL, SMPT_PASS} = process.env

// console.log(process.env.SMPT_MAIL)
// console.log(process.env.SMPT_PASS)

smtp = {
    mail: "sn7dev@gmail.com",
    pass: "zwbpsetytzbatdmj"
}
// console.log(smpt.mail)

module.exports = {
    smtp,
}