const kyc = require('../models/kycModel')
const User = require('../models/userModel')

const loadKYC = async(req, res) => {
    try {
        res.render('kyc')
    } catch (error) {
        console.log(error.message)
    }
}

const form1 = async(req, res) =>{
    try {
        if (!req.session.userId) {
            res.status(401).send('Unauthorized');
            res.redirect('/')
            return;
        }else{
            const userId = req.session.userId
            console.log(userId)
            panNumber = req.body.panNumber
            
        }
    } catch (error) {
        console.log(error.message)
    }
}

const form2 = async(req, res) =>{

}

const form3 = async(req, res) =>{

}


module.exports = {
    loadKYC,
    form1,
    form2,
    form3

}