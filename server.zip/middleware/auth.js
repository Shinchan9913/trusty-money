const isLogin = async(req, res, next) =>{
    try {
        if(req.session.user_id){}
        else{
            res.redirect('/')
        }
        next()
    } catch (error) {
        console.log(error.message)
    }
}

const isLogout = async(req, res, next) =>{
    try {
        if(req.session.user_id)
            res.redirect('/home')
        next()
    } catch (error) {
        console.log(error.message)
    }
}

const verifyKYC = async(req, res, next) =>{
    try {
        if(req.body.panNo == "ASDFG1234H"){}
        else{
            res.render('kyc', {error : "INVALID PAN!"})
        }
    } catch (error) {
        console.log(error.message)
    }
}

module.exports = {
    isLogin,
    isLogout,
    verifyKYC
}