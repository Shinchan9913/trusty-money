const express = require('express');
const router = express();

const kycController = require('../controllers/kycController')

router.set('view engine', 'ejs')
router.set('views', './views/users')

router.get('/', kycController.loadKYC)

router.post('/form1', kycController.form1)

module.exports = router;